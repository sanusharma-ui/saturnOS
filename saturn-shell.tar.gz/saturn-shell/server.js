'use strict';
const http = require('http'), fs = require('fs'), path = require('path'), os = require('os'), cp = require('child_process');
const HOME = '/home/sanu', PUB = path.join(__dirname, 'public'), TRASH = path.join(HOME, '.saturn-trash');
for (const d of [TRASH, path.join(HOME, 'Desktop')]) { try { fs.mkdirSync(d, { recursive: true }); } catch (e) {} }
let RH = HOME; try { RH = fs.realpathSync(HOME); } catch (e) {}
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.gif': 'image/gif', '.webp': 'image/webp', '.bmp': 'image/bmp', '.ico': 'image/x-icon', '.mp3': 'audio/mpeg', '.wav': 'audio/wav', '.ogg': 'audio/ogg', '.flac': 'audio/flac', '.m4a': 'audio/mp4', '.mp4': 'video/mp4', '.webm': 'video/webm', '.txt': 'text/plain; charset=utf-8', '.pdf': 'application/pdf' };
class E extends Error { constructor(c, m) { super(m); this.c = c; } }
const inH = p => p === RH || p.startsWith(RH + path.sep);
function safe(p, exist = true) {
  if (typeof p !== 'string' || !p || p.length > 4096 || p.includes('\0')) throw new E(400, 'Invalid path');
  let r = path.resolve(RH, p);
  if (!inH(r)) throw new E(403, 'Outside home folder');
  try { r = exist ? fs.realpathSync(r) : path.join(fs.realpathSync(path.dirname(r)), path.basename(r)); } catch (e) { throw new E(404, 'Not found'); }
  if (!inH(r)) throw new E(403, 'Outside home folder');
  return r;
}
const nm = n => { if (typeof n !== 'string' || !n || n.length > 255 || n.includes('/') || n.includes('\0') || n === '.' || n === '..') throw new E(400, 'Invalid name'); return n; };
const J = (res, c, o) => { const b = JSON.stringify(o); res.writeHead(c, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(b), 'Cache-Control': 'no-store' }); res.end(b); };
const body = (req, max = 8e6) => new Promise((ok, no) => {
  let n = 0; const c = [];
  req.on('data', d => { n += d.length; if (n > max) { no(new E(413, 'Body too large')); req.destroy(); } else c.push(d); });
  req.on('end', () => { try { ok(c.length ? JSON.parse(Buffer.concat(c)) : {}); } catch (e) { no(new E(400, 'Bad JSON')); } });
  req.on('error', no);
});
function uniq(dir, name) {
  let t = path.join(dir, name), i = 1; const ext = path.extname(name), base = path.basename(name, ext);
  while (fs.existsSync(t)) t = path.join(dir, `${base} (${i++})${ext}`);
  return t;
}
function mv(a, b) { try { fs.renameSync(a, b); } catch (e) { fs.cpSync(a, b, { recursive: true }); fs.rmSync(a, { recursive: true, force: true }); } }
// ---- sysinfo ----
let pcpu = null, pp = new Map(), pt = Date.now();
function cpuPct() {
  const l = fs.readFileSync('/proc/stat', 'utf8').split('\n')[0].split(/\s+/).slice(1).map(Number);
  const idle = l[3] + (l[4] || 0), tot = l.reduce((a, b) => a + b, 0); let u = 0;
  if (pcpu) u = 1 - (idle - pcpu.i) / Math.max(1, tot - pcpu.t);
  pcpu = { i: idle, t: tot }; return Math.round(Math.max(0, u) * 1000) / 10;
}
function procs() {
  const now = Date.now(), dt = Math.max(0.2, (now - pt) / 1000), np = new Map(), out = [];
  for (const d of fs.readdirSync('/proc')) {
    if (!/^\d+$/.test(d)) continue;
    try {
      const s = fs.readFileSync('/proc/' + d + '/stat', 'utf8'), i = s.lastIndexOf(')'), f = s.slice(i + 2).split(' ');
      const tk = +f[11] + +f[12]; np.set(d, tk); const pv = pp.get(d);
      out.push({ pid: +d, name: s.slice(s.indexOf('(') + 1, i), cpu: pv == null ? 0 : Math.round((tk - pv) / dt * 10) / 10, mem: +f[21] * 4096 });
    } catch (e) {}
  }
  pp = np; pt = now;
  return out.sort((a, b) => b.cpu - a.cpu || b.mem - a.mem).slice(0, 8);
}
function sysinfo() {
  const mi = {}; for (const l of fs.readFileSync('/proc/meminfo', 'utf8').split('\n')) { const m = /^(\w+):\s+(\d+)/.exec(l); if (m) mi[m[1]] = +m[2] * 1024; }
  let disk = { total: 0, free: 0 }; try { const s = fs.statfsSync('/'); disk = { total: s.blocks * s.bsize, free: s.bavail * s.bsize }; } catch (e) {}
  return { cpu: cpuPct(), cores: os.cpus().length, mem: { total: mi.MemTotal || 0, avail: mi.MemAvailable || 0 }, disk, uptime: os.uptime(), kernel: os.release(), hostname: os.hostname(), procs: procs() };
}
// ---- handlers ----
const APPS = { terminal: ['xfce4-terminal'], files: ['thunar'], browser: ['firefox'], chromium: ['chromium'] };
function spawnDetached(cmd, args) {
  const c = cp.spawn(cmd, args, { detached: true, stdio: 'ignore', env: Object.assign({}, process.env, { DISPLAY: ':0' }) });
  c.on('error', () => {}); c.unref();
}
function serveFile(req, res, fp) {
  const st = fs.statSync(fp); if (!st.isFile()) throw new E(404, 'Not a file');
  const h = { 'Content-Type': MIME[path.extname(fp).toLowerCase()] || 'application/octet-stream', 'Accept-Ranges': 'bytes' };
  let s = 0, e = st.size - 1, code = 200; const m = /^bytes=(\d*)-(\d*)$/.exec(req.headers.range || '');
  if (m && (m[1] || m[2])) {
    if (m[1] === '') s = Math.max(0, st.size - +m[2]); else { s = +m[1]; if (m[2]) e = Math.min(e, +m[2]); }
    if (s > e || s >= st.size) { res.writeHead(416, { 'Content-Range': 'bytes */' + st.size }); return res.end(); }
    code = 206; h['Content-Range'] = `bytes ${s}-${e}/${st.size}`;
  }
  h['Content-Length'] = st.size === 0 ? 0 : e - s + 1; res.writeHead(code, h);
  if (st.size === 0) return res.end();
  fs.createReadStream(fp, { start: s, end: e }).on('error', () => res.destroy()).pipe(res);
}
function search(q, root) {
  q = q.toLowerCase(); const out = [], qu = [[root, 0]]; let seen = 0;
  while (qu.length && out.length < 60 && seen < 20000) {
    const [d, dep] = qu.shift(); let ents; try { ents = fs.readdirSync(d, { withFileTypes: true }); } catch (e) { continue; }
    for (const en of ents) {
      if (en.name[0] === '.' || en.name === 'node_modules') continue; seen++;
      const p = path.join(d, en.name);
      if (en.name.toLowerCase().includes(q)) { out.push({ name: en.name, path: p, type: en.isDirectory() ? 'dir' : 'file' }); if (out.length >= 60) break; }
      if (en.isDirectory() && dep < 4) qu.push([p, dep + 1]);
    }
  }
  return out;
}
async function api(req, res, u) {
  const q = u.searchParams, p = u.pathname;
  if (req.method === 'GET') {
    if (p === '/api/sysinfo') return J(res, 200, sysinfo());
    if (p === '/api/file') return serveFile(req, res, safe(q.get('path')));
    if (p === '/api/fs/list') {
      const d = safe(q.get('path') || RH); if (!fs.statSync(d).isDirectory()) throw new E(400, 'Not a folder');
      const items = [];
      for (const n of fs.readdirSync(d).slice(0, 2000)) {
        try { const s = fs.statSync(path.join(d, n)); items.push({ name: n, type: s.isDirectory() ? 'dir' : 'file', size: s.size, mtime: s.mtimeMs }); } catch (e) {}
      }
      items.sort((a, b) => (a.type === b.type ? 0 : a.type === 'dir' ? -1 : 1) || a.name.localeCompare(b.name));
      return J(res, 200, { path: d, items });
    }
    if (p === '/api/fs/read') {
      const f = safe(q.get('path')), s = fs.statSync(f); if (!s.isFile()) throw new E(400, 'Not a file'); if (s.size > 2e6) throw new E(413, 'File larger than 2 MB');
      return J(res, 200, { path: f, content: fs.readFileSync(f, 'utf8') });
    }
    if (p === '/api/fs/search') {
      const s = String(q.get('q') || '').trim(); if (!s || s.length > 100) throw new E(400, 'Invalid query');
      return J(res, 200, { results: search(s, safe(q.get('path') || RH)) });
    }
    throw new E(404, 'Unknown endpoint');
  }
  if (req.method !== 'POST') throw new E(405, 'Method not allowed');
  if (p === '/api/llm') {
    const b = await body(req, 2e6); if (!Array.isArray(b.messages)) throw new E(400, 'messages required');
    const payload = JSON.stringify({ messages: b.messages.slice(-40), stream: true, temperature: 0.4, max_tokens: 1024 });
    const up = http.request({ host: '127.0.0.1', port: 8080, path: '/v1/chat/completions', method: 'POST', headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) } }, r => {
      res.writeHead(r.statusCode || 200, { 'Content-Type': r.headers['content-type'] || 'text/event-stream', 'Cache-Control': 'no-store' }); r.pipe(res);
    });
    up.on('error', () => { if (!res.headersSent) J(res, 502, { error: 'Local model is not reachable on :8080' }); else res.end(); });
    res.on('close', () => up.destroy()); return up.end(payload);
  }
  const b = await body(req);
  if (p === '/api/launch') {
    const a = APPS[b.app]; if (!a) throw new E(400, 'App not allowed');
    let args = [];
    if (b.path) { let d = safe(b.path); if (!fs.statSync(d).isDirectory()) d = path.dirname(d); args = b.app === 'terminal' ? ['--working-directory=' + d] : b.app === 'files' ? [d] : []; }
    spawnDetached(a[0], args); return J(res, 200, { ok: true });
  }
  if (p === '/api/power') {
    if (b.action !== 'shutdown' && b.action !== 'reboot') throw new E(400, 'Invalid action');
    spawnDetached('doas', [b.action === 'shutdown' ? 'poweroff' : 'reboot']); return J(res, 200, { ok: true });
  }
  if (p === '/api/fs/write') {
    if (typeof b.content !== 'string' || b.content.length > 5e6) throw new E(400, 'Invalid content');
    const f = safe(b.path, false); if (fs.existsSync(f) && fs.statSync(f).isDirectory()) throw new E(400, 'Path is a folder');
    fs.writeFileSync(f, b.content); return J(res, 200, { ok: true });
  }
  if (p === '/api/fs/mkdir') { const d = safe(b.path, true); const t = path.join(d, nm(b.name)); if (fs.existsSync(t)) throw new E(409, 'Already exists'); fs.mkdirSync(t); return J(res, 200, { ok: true }); }
  if (p === '/api/fs/rename') {
    const s = safe(b.path), t = path.join(path.dirname(s), nm(b.name)); if (s === RH) throw new E(403, 'Not allowed');
    if (fs.existsSync(t)) throw new E(409, 'Already exists'); fs.renameSync(s, t); return J(res, 200, { ok: true });
  }
  if (p === '/api/fs/delete') {
    const s = safe(b.path); if (s === RH || s === TRASH || path.dirname(s) === RH && path.basename(s) === 'Desktop') throw new E(403, 'Not allowed');
    if (s.startsWith(TRASH + path.sep)) fs.rmSync(s, { recursive: true, force: true }); else mv(s, uniq(TRASH, path.basename(s)));
    return J(res, 200, { ok: true });
  }
  if (p === '/api/fs/copy' || p === '/api/fs/move') {
    const s = safe(b.src), d = safe(b.dest); if (!fs.statSync(d).isDirectory()) throw new E(400, 'Destination is not a folder');
    if (s === RH || d === s || d.startsWith(s + path.sep)) throw new E(400, 'Cannot place a folder inside itself');
    if (p === '/api/fs/move' && path.dirname(s) === d) return J(res, 200, { ok: true });
    const t = uniq(d, path.basename(s));
    if (p === '/api/fs/copy') fs.cpSync(s, t, { recursive: true }); else mv(s, t);
    return J(res, 200, { ok: true });
  }
  throw new E(404, 'Unknown endpoint');
}
function stat(req, res, u) {
  let rel; try { rel = decodeURIComponent(u.pathname); } catch (e) { throw new E(400, 'Bad URL'); }
  if (rel === '/') rel = '/index.html';
  let fp = path.join(PUB, path.normalize(rel));
  try { fp = fs.realpathSync(fp); } catch (e) { throw new E(404, 'Not found'); }
  if (!fp.startsWith(PUB + path.sep)) throw new E(403, 'Forbidden');
  const s = fs.statSync(fp); if (!s.isFile()) throw new E(404, 'Not found');
  res.writeHead(200, { 'Content-Type': MIME[path.extname(fp).toLowerCase()] || 'application/octet-stream', 'Content-Length': s.size, 'Cache-Control': 'no-cache' });
  fs.createReadStream(fp).pipe(res);
}
http.createServer(async (req, res) => {
  try {
    const u = new URL(req.url, 'http://localhost');
    if (u.pathname.startsWith('/api/')) await api(req, res, u);
    else if (req.method === 'GET' || req.method === 'HEAD') stat(req, res, u);
    else throw new E(405, 'Method not allowed');
  } catch (e) {
    const c = e instanceof E ? e.c : (e && e.code === 'ENOENT' ? 404 : e && e.code === 'EACCES' ? 403 : 500);
    if (!res.headersSent) J(res, c, { error: e instanceof E ? e.message : (c === 500 ? 'Internal error' : e.message) }); else res.end();
  }
}).listen(3000, '127.0.0.1', () => console.log('Saturn shell on http://127.0.0.1:3000'));
process.on('uncaughtException', e => console.error('uncaught', e && e.message));
